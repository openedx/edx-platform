def seventeen():
    return 17

def fortytwo(x):
    return 42+x
