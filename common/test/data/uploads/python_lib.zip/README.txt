Use this directory to make the python_lib.zip file above:

$ zip -r python_lib.zip python_lib_zip/*
