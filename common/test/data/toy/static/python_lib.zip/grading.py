def is_even(x):
    return x % 2 == 0
