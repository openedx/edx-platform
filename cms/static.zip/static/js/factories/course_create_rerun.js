define(['jquery', 'jquery.form', 'js/views/course_rerun'], function($) {
    'use strict';
    return function() {};
});
