import * as ContextCourse from 'js/models/course';

export {ContextCourse}
